import React, { useState } from 'react';
import { Copy, Check, Terminal, ExternalLink, Sparkles } from 'lucide-react';
import { PathSeparator } from '../types/tree';

interface PathTextBoxProps {
  currentPathSegments?: string[];
  variant?: 'debug' | 'release';
  onInspectApk?: () => void;
}

export const PathTextBox: React.FC<PathTextBoxProps> = ({
  currentPathSegments = ['app', 'build', 'outputs', 'apk', 'debug', 'app-debug.apk'],
  variant = 'debug',
  onInspectApk,
}) => {
  const [copied, setCopied] = useState(false);
  const [separator, setSeparator] = useState<PathSeparator>(' / ');
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  // Compute displayed path string based on separator
  const displayedPath = currentPathSegments.join(separator);

  const handleCopyPath = async () => {
    try {
      await navigator.clipboard.writeText(displayedPath);
      setCopied(true);
      setTimeout(() => setCopied(false), 2200);
    } catch {
      // Fallback
    }
  };

  const handleCopyCommand = async (cmd: string, label: string) => {
    try {
      await navigator.clipboard.writeText(cmd);
      setCopiedCommand(label);
      setTimeout(() => setCopiedCommand(null), 2000);
    } catch {
      // Fallback
    }
  };

  const posixPath = currentPathSegments.join('/');
  const adbCommand = `adb install -r ${posixPath}`;
  const cdCommand = `cd ${currentPathSegments.slice(0, -1).join('/')} && ls -lh`;

  return (
    <div className="w-full max-w-3xl flex flex-col items-center">
      {/* Visual isolation spacer / divider label */}
      <div className="flex items-center gap-3 w-full mb-3 px-4">
        <div className="h-px bg-zinc-700/60 flex-1" />
        <span className="text-[11px] font-mono tracking-wider uppercase text-zinc-400 font-medium">
          Resolved Build Artifact Location
        </span>
        <div className="h-px bg-zinc-700/60 flex-1" />
      </div>

      {/* The Requested Plain Text Box with Light Grey Background */}
      <div className="w-full relative group">
        <div className="bg-[#e5e7eb] text-[#111827] rounded-lg border border-slate-300 shadow-lg px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4 transition-all hover:bg-[#edeef2] hover:shadow-xl">
          {/* Path Display */}
          <div className="flex items-center gap-3 overflow-x-auto w-full py-1">
            <span className="text-zinc-500 font-mono text-sm select-none shrink-0 font-medium">
              $
            </span>
            <code
              className="font-mono text-[14px] sm:text-[15.5px] font-semibold tracking-tight text-[#111827] whitespace-nowrap selection:bg-emerald-300 selection:text-black"
              title="Click to copy path"
              onClick={handleCopyPath}
            >
              {displayedPath}
            </code>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0 self-end sm:self-center">
            {/* Copy Button */}
            <button
              onClick={handleCopyPath}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition-all shadow-sm ${
                copied
                  ? 'bg-emerald-600 text-white font-semibold'
                  : 'bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 active:scale-95'
              }`}
              title="Copy path to clipboard"
            >
              {copied ? (
                <>
                  <Check size={14} className="stroke-[2.5]" />
                  <span>Copied!</span>
                </>
              ) : (
                <>
                  <Copy size={14} className="text-slate-600" />
                  <span>Copy Path</span>
                </>
              )}
            </button>

            {onInspectApk && (
              <button
                onClick={onInspectApk}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-emerald-100 text-emerald-900 hover:bg-emerald-200 border border-emerald-300 transition-all active:scale-95 shadow-sm"
                title="Inspect APK metadata"
              >
                <Sparkles size={13} className="text-emerald-700" />
                <span>Inspect APK</span>
              </button>
            )}
          </div>
        </div>

        {/* Format Selector and Quick Commands */}
        <div className="flex flex-wrap items-center justify-between gap-2 mt-2 px-1 text-xs">
          <div className="flex items-center gap-2 text-zinc-400">
            <span className="text-[11px] text-zinc-400">Format:</span>
            <button
              onClick={() => setSeparator(' / ')}
              className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                separator === ' / '
                  ? 'bg-zinc-700 text-emerald-400 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              app / build / ...
            </button>
            <button
              onClick={() => setSeparator('/')}
              className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                separator === '/'
                  ? 'bg-zinc-700 text-emerald-400 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              POSIX (app/build/...)
            </button>
            <button
              onClick={() => setSeparator('\\')}
              className={`px-2 py-0.5 rounded text-[11px] font-mono transition-colors ${
                separator === '\\'
                  ? 'bg-zinc-700 text-emerald-400 font-semibold'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800'
              }`}
            >
              Windows (\)
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => handleCopyCommand(adbCommand, 'adb')}
              className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80 px-2 py-0.5 rounded transition-colors font-mono"
              title="Copy ADB install command"
            >
              <Terminal size={12} />
              <span>{copiedCommand === 'adb' ? 'Copied ADB cmd!' : 'Copy adb install'}</span>
            </button>
            <button
              onClick={() => handleCopyCommand(cdCommand, 'cd')}
              className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/80 px-2 py-0.5 rounded transition-colors font-mono"
              title="Copy shell cd command"
            >
              <span>{copiedCommand === 'cd' ? 'Copied cd cmd!' : 'Copy cd directory'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { FolderIcon } from './FolderIcon';
import { AndroidIcon } from './AndroidIcon';
import { Info, Sparkles, CheckCircle2, ChevronRight, FileCode, HardDrive } from 'lucide-react';
import { BuildVariant } from '../types/tree';

interface DirectoryTreeProps {
  variant: BuildVariant;
  showFullProject: boolean;
  onSelectApk: () => void;
  onSelectSourceFile?: (fileName: string) => void;
}

export const DirectoryTree: React.FC<DirectoryTreeProps> = ({
  variant,
  showFullProject,
  onSelectApk,
  onSelectSourceFile,
}) => {
  const apkFileName = variant === 'debug' ? 'app-debug.apk' : 'app-release.apk';
  const variantFolderName = variant;

  return (
    <div className="w-full flex justify-center py-4 select-none">
      <div className="relative inline-block min-w-[340px] sm:min-w-[460px] md:min-w-[540px] px-2 py-4">
        {/* Tree Container with authentic IDE guide styling */}
        <div className="flex flex-col space-y-1 font-mono text-[13.5px] sm:text-[14.5px]">
          
          {/* Level 0: app */}
          <div className="relative group">
            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800/40 hover:bg-zinc-800/70 border border-zinc-700/50 transition-all duration-150">
              <FolderIcon variant="root" size={24} isOpen={true} />
              <span className="font-semibold text-zinc-100 tracking-tight text-[15px]">
                app
              </span>
              <span className="text-[11px] text-zinc-400 font-sans ml-auto bg-zinc-800 px-2 py-0.5 rounded border border-zinc-700">
                Root Module
              </span>
            </div>
          </div>

          {/* Level 1: build (nested under app) */}
          <div className="relative pl-6 sm:pl-8 group">
            {/* Guide line down from 'app' */}
            <div className="absolute left-3 sm:left-4 top-0 bottom-4 w-px bg-zinc-600/60" />
            {/* Horizontal branch elbow to 'build' */}
            <div className="absolute left-3 sm:left-4 top-5 w-3.5 sm:w-4 h-px bg-zinc-600/60" />

            <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800/40 hover:bg-zinc-800/70 border border-amber-500/20 transition-all duration-150">
              <FolderIcon variant="build" size={22} isOpen={true} />
              <span className="font-medium text-amber-200 tracking-tight">
                build
              </span>
              <span className="text-[11px] text-amber-400/80 font-sans ml-auto bg-amber-950/40 px-2 py-0.5 rounded border border-amber-800/40">
                Gradle Output
              </span>
            </div>

            {/* Level 2: outputs (nested under build) */}
            <div className="relative pl-6 sm:pl-8 mt-1 group">
              {/* Vertical line from 'build' */}
              <div className="absolute left-3 sm:left-4 top-0 bottom-4 w-px bg-zinc-600/60" />
              {/* Horizontal branch elbow to 'outputs' */}
              <div className="absolute left-3 sm:left-4 top-5 w-3.5 sm:w-4 h-px bg-zinc-600/60" />

              <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800/40 hover:bg-zinc-800/70 border border-cyan-500/20 transition-all duration-150">
                <FolderIcon variant="outputs" size={22} isOpen={true} />
                <span className="font-medium text-cyan-200 tracking-tight">
                  outputs
                </span>
                <span className="text-[11px] text-cyan-400/80 font-sans ml-auto bg-cyan-950/40 px-2 py-0.5 rounded border border-cyan-800/40">
                  Target Artifacts
                </span>
              </div>

              {/* Level 3: apk (nested under outputs) */}
              <div className="relative pl-6 sm:pl-8 mt-1 group">
                {/* Vertical line from 'outputs' */}
                <div className="absolute left-3 sm:left-4 top-0 bottom-4 w-px bg-zinc-600/60" />
                {/* Horizontal branch elbow to 'apk' */}
                <div className="absolute left-3 sm:left-4 top-5 w-3.5 sm:w-4 h-px bg-zinc-600/60" />

                <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800/40 hover:bg-zinc-800/70 border border-emerald-500/20 transition-all duration-150">
                  <FolderIcon variant="apk" size={22} isOpen={true} />
                  <span className="font-medium text-emerald-200 tracking-tight">
                    apk
                  </span>
                  <span className="text-[11px] text-emerald-400/80 font-sans ml-auto bg-emerald-950/40 px-2 py-0.5 rounded border border-emerald-800/40">
                    Application Packages
                  </span>
                </div>

                {/* Level 4: debug (nested under apk) */}
                <div className="relative pl-6 sm:pl-8 mt-1 group">
                  {/* Vertical line from 'apk' */}
                  <div className="absolute left-3 sm:left-4 top-0 bottom-5 w-px bg-zinc-600/60" />
                  {/* Horizontal branch elbow to 'debug' */}
                  <div className="absolute left-3 sm:left-4 top-5 w-3.5 sm:w-4 h-px bg-zinc-600/60" />

                  <div className="flex items-center gap-2.5 px-3 py-2 rounded-lg bg-zinc-800/40 hover:bg-zinc-800/70 border border-purple-500/20 transition-all duration-150">
                    <FolderIcon variant="debug" size={22} isOpen={true} />
                    <span className="font-medium text-purple-200 tracking-tight">
                      {variantFolderName}
                    </span>
                    <span className="text-[11px] text-purple-400/80 font-sans ml-auto bg-purple-950/40 px-2 py-0.5 rounded border border-purple-800/40">
                      Build Variant
                    </span>
                  </div>

                  {/* Level 5: FINAL ARTIFACT (app-debug.apk) nested inside debug */}
                  <div className="relative pl-6 sm:pl-8 mt-2">
                    {/* Vertical line down to the APK */}
                    <div className="absolute left-3 sm:left-4 top-0 h-6 w-px bg-emerald-500/70" />
                    {/* Horizontal branch elbow leading directly into the APK card */}
                    <div className="absolute left-3 sm:left-4 top-6 w-3.5 sm:w-4 h-px bg-emerald-500/70" />

                    {/* Distinct highlighted APK card with Android logo overlay */}
                    <div
                      onClick={onSelectApk}
                      role="button"
                      tabIndex={0}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          onSelectApk();
                        }
                      }}
                      className="cursor-pointer group relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 sm:px-4 sm:py-3 rounded-xl bg-gradient-to-r from-emerald-950/70 via-zinc-900 to-zinc-900/95 border-2 border-emerald-500 shadow-[0_0_25px_rgba(61,220,132,0.18)] hover:shadow-[0_0_35px_rgba(61,220,132,0.3)] hover:border-emerald-400 transition-all duration-200 transform hover:-translate-y-0.5"
                    >
                      {/* Left side: Android icon + File Name */}
                      <div className="flex items-center gap-3">
                        {/* Android logo badge with gentle pulse */}
                        <div className="relative flex items-center justify-center w-10 h-10 rounded-lg bg-emerald-950/90 border border-emerald-400/60 shrink-0 shadow-inner">
                          <AndroidIcon size={26} color="#3DDC84" />
                          <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping opacity-75" />
                          <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400" />
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-emerald-300 tracking-tight text-[15px] sm:text-[16px] group-hover:text-emerald-200">
                              {apkFileName}
                            </span>
                            <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10.5px] font-sans font-semibold px-2 py-0.5 rounded-full uppercase tracking-wider">
                              Target APK
                            </span>
                          </div>
                          <p className="text-[11.5px] text-zinc-400 font-sans flex items-center gap-2 mt-0.5">
                            <span>Package: <strong className="text-zinc-300 font-mono">com.example.scicalc</strong></span>
                            <span>•</span>
                            <span>3.4 MB</span>
                          </p>
                        </div>
                      </div>

                      {/* Right side: Action indicator */}
                      <div className="flex items-center gap-2 self-end sm:self-center">
                        <span className="text-[11px] font-sans text-emerald-400/90 bg-emerald-950/60 border border-emerald-800/60 px-2.5 py-1 rounded-md flex items-center gap-1 group-hover:bg-emerald-900/60 transition-colors">
                          <Sparkles size={12} className="text-emerald-400" />
                          <span>Inspect Artifact</span>
                          <ChevronRight size={13} className="text-emerald-400" />
                        </span>
                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>

          {/* Optional: Full Project Sibling Folders (when enabled, shows src/main and gradle files) */}
          {showFullProject && (
            <div className="relative pl-6 sm:pl-8 mt-3 pt-3 border-t border-zinc-800/80">
              <div className="text-[11px] font-sans uppercase tracking-wider text-zinc-400 font-semibold mb-2">
                Project Source Context (Scientific Calculator)
              </div>

              {/* src / main folder */}
              <div className="space-y-1.5 text-zinc-400 text-xs font-mono">
                {/* MainActivity.kt */}
                <div
                  onClick={() => onSelectSourceFile && onSelectSourceFile('MainActivity.kt')}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded bg-zinc-800/30 hover:bg-zinc-800/60 border border-zinc-800 cursor-pointer text-zinc-300 hover:text-white transition-colors"
                >
                  <FileCode size={16} className="text-purple-400" />
                  <span className="text-zinc-200">src/main/java/com/example/scicalc/</span>
                  <span className="font-semibold text-purple-300">MainActivity.kt</span>
                  <span className="text-[10px] text-zinc-400 ml-auto font-sans bg-zinc-800 px-1.5 py-0.5 rounded">
                    WebView Host
                  </span>
                </div>

                {/* AndroidManifest.xml */}
                <div
                  onClick={() => onSelectSourceFile && onSelectSourceFile('AndroidManifest.xml')}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded bg-zinc-800/30 hover:bg-zinc-800/60 border border-zinc-800 cursor-pointer text-zinc-300 hover:text-white transition-colors"
                >
                  <FileCode size={16} className="text-emerald-400" />
                  <span className="text-zinc-200">src/main/</span>
                  <span className="font-semibold text-emerald-300">AndroidManifest.xml</span>
                  <span className="text-[10px] text-zinc-400 ml-auto font-sans bg-zinc-800 px-1.5 py-0.5 rounded">
                    INTERNET Permission
                  </span>
                </div>

                {/* WebView Assets index.html */}
                <div
                  onClick={() => onSelectSourceFile && onSelectSourceFile('index.html')}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded bg-zinc-800/30 hover:bg-zinc-800/60 border border-zinc-800 cursor-pointer text-zinc-300 hover:text-white transition-colors"
                >
                  <FileCode size={16} className="text-amber-400" />
                  <span className="text-zinc-200">src/main/assets/</span>
                  <span className="font-semibold text-amber-300">www/index.html</span>
                  <span className="text-[10px] text-zinc-400 ml-auto font-sans bg-zinc-800 px-1.5 py-0.5 rounded">
                    Scientific Calc UI
                  </span>
                </div>

                {/* build.gradle (Module: app) */}
                <div
                  onClick={() => onSelectSourceFile && onSelectSourceFile('app/build.gradle')}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded bg-zinc-800/30 hover:bg-zinc-800/60 border border-zinc-800 cursor-pointer text-zinc-300 hover:text-white transition-colors"
                >
                  <FileCode size={16} className="text-blue-400" />
                  <span>app/build.gradle</span>
                  <span className="text-[10px] text-zinc-400 ml-auto font-sans bg-zinc-800 px-1.5 py-0.5 rounded">
                    SDK 33 Config
                  </span>
                </div>

                {/* settings.gradle & root build.gradle */}
                <div
                  onClick={() => onSelectSourceFile && onSelectSourceFile('settings.gradle')}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded bg-zinc-800/30 hover:bg-zinc-800/60 border border-zinc-800 cursor-pointer text-zinc-400 hover:text-zinc-200 transition-colors"
                >
                  <FileCode size={16} className="text-zinc-500" />
                  <span>settings.gradle (ScientificCalculator)</span>
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

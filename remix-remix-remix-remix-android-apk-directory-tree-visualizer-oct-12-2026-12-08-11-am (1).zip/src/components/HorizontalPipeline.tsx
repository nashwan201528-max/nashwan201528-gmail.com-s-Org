import React from 'react';
import { ArrowRight, ChevronRight, Sparkles } from 'lucide-react';
import { FolderIcon } from './FolderIcon';
import { AndroidIcon } from './AndroidIcon';
import { BuildVariant } from '../types/tree';

interface HorizontalPipelineProps {
  variant: BuildVariant;
  onSelectApk: () => void;
}

export const HorizontalPipeline: React.FC<HorizontalPipelineProps> = ({
  variant,
  onSelectApk,
}) => {
  const apkFileName = variant === 'debug' ? 'app-debug.apk' : 'app-release.apk';

  const steps = [
    { name: 'app', label: 'Module', variant: 'root' as const },
    { name: 'build', label: 'Gradle Output', variant: 'build' as const },
    { name: 'outputs', label: 'Deliverables', variant: 'outputs' as const },
    { name: 'apk', label: 'Package Type', variant: 'apk' as const },
    { name: variant, label: 'Variant', variant: 'debug' as const },
  ];

  return (
    <div className="w-full flex flex-col items-center py-6 px-2 overflow-x-auto">
      <div className="flex items-center gap-2 sm:gap-3 p-4 bg-zinc-900/60 border border-zinc-800 rounded-2xl shadow-xl min-w-max">
        {steps.map((step, idx) => (
          <React.Fragment key={step.name}>
            <div className="flex flex-col items-center p-3 rounded-xl bg-zinc-800/50 border border-zinc-700/60 min-w-[85px]">
              <FolderIcon variant={step.variant} size={24} isOpen={true} />
              <span className="font-mono font-semibold text-zinc-100 text-sm mt-1.5">
                {step.name}
              </span>
              <span className="text-[10px] text-zinc-400 font-sans mt-0.5">
                {step.label}
              </span>
            </div>

            {/* Arrow connector */}
            <ChevronRight size={18} className="text-zinc-600 shrink-0" />
          </React.Fragment>
        ))}

        {/* Final APK Node */}
        <div
          onClick={onSelectApk}
          className="flex flex-col items-center p-3 rounded-xl bg-gradient-to-b from-emerald-950 to-zinc-900 border-2 border-emerald-500 shadow-[0_0_20px_rgba(61,220,132,0.2)] hover:border-emerald-400 cursor-pointer min-w-[140px] transition-all hover:scale-105"
        >
          <div className="relative p-1">
            <AndroidIcon size={28} color="#3DDC84" />
          </div>
          <span className="font-mono font-bold text-emerald-300 text-sm mt-1">
            {apkFileName}
          </span>
          <span className="text-[10px] text-emerald-400 font-sans font-medium flex items-center gap-1 mt-0.5">
            <Sparkles size={10} />
            Generated APK
          </span>
        </div>
      </div>
    </div>
  );
};

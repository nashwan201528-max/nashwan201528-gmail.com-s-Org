import React, { useState } from 'react';
import { X, Copy, Check, Terminal, ExternalLink, ShieldCheck, Cpu, HardDrive, Smartphone, Package, CheckCircle2 } from 'lucide-react';
import { AndroidIcon } from './AndroidIcon';
import { BuildVariant } from '../types/tree';

interface ApkInspectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  variant: BuildVariant;
  onOpenPhonePreview: () => void;
}

export const ApkInspectorModal: React.FC<ApkInspectorModalProps> = ({
  isOpen,
  onClose,
  variant,
  onOpenPhonePreview,
}) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  if (!isOpen) return null;

  const fileName = variant === 'debug' ? 'app-debug.apk' : 'app-release.apk';
  const fullPath = `app/build/outputs/apk/${variant}/${fileName}`;
  const adbCommand = `adb install -r ${fullPath}`;

  const copyToClipboard = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedCmd(label);
      setTimeout(() => setCopiedCmd(null), 2000);
    } catch {
      // Fallback
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-zinc-900 border border-zinc-700 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header with Android Badge */}
        <div className="p-6 border-b border-zinc-800 bg-gradient-to-r from-emerald-950/60 via-zinc-900 to-zinc-900 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-950 border border-emerald-500/50 flex items-center justify-center shadow-lg shadow-emerald-950/50">
              <AndroidIcon size={30} color="#3DDC84" />
            </div>
            <div>
              <div className="flex items-center gap-2.5">
                <h3 className="font-mono font-bold text-lg text-emerald-300">
                  {fileName}
                </h3>
                <span className="text-[11px] font-sans font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2 py-0.5 rounded uppercase">
                  {variant}
                </span>
              </div>
              <p className="text-xs font-mono text-zinc-400 mt-0.5">
                {fullPath}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm">
          
          {/* Key Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-zinc-950/60 border border-zinc-800 p-3 rounded-xl">
              <span className="text-[11px] text-zinc-400 font-sans block mb-1">Package</span>
              <span className="font-mono text-xs font-bold text-zinc-200 block truncate" title="com.example.scicalc">
                com.example.scicalc
              </span>
            </div>
            <div className="bg-zinc-950/60 border border-zinc-800 p-3 rounded-xl">
              <span className="text-[11px] text-zinc-400 font-sans block mb-1">APK Size</span>
              <span className="font-mono text-xs font-bold text-emerald-400 block">
                3.42 MB
              </span>
            </div>
            <div className="bg-zinc-950/60 border border-zinc-800 p-3 rounded-xl">
              <span className="text-[11px] text-zinc-400 font-sans block mb-1">Min / Target SDK</span>
              <span className="font-mono text-xs font-bold text-zinc-200 block">
                24 / 34 (Android 14)
              </span>
            </div>
            <div className="bg-zinc-950/60 border border-zinc-800 p-3 rounded-xl">
              <span className="text-[11px] text-zinc-400 font-sans block mb-1">Signature</span>
              <span className="font-mono text-xs font-bold text-purple-300 block">
                V1, V2, V3 (Debug)
              </span>
            </div>
          </div>

          {/* Quick Action: Test in Phone Simulator */}
          <div className="bg-gradient-to-r from-emerald-950/40 via-zinc-950 to-zinc-950 border border-emerald-800/40 p-4 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-lg bg-emerald-900/50 text-emerald-400 border border-emerald-700/50">
                <Smartphone size={20} />
              </div>
              <div>
                <h4 className="font-semibold text-zinc-100 text-sm">
                  Scientific Calculator WebView App
                </h4>
                <p className="text-xs text-zinc-400 mt-0.5">
                  Launches <code className="text-emerald-300 font-mono">MainActivity.kt</code> loading the bundled <code className="text-amber-300 font-mono">assets/www/index.html</code>.
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                onClose();
                onOpenPhonePreview();
              }}
              className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs shadow-md transition-colors flex items-center gap-1.5 shrink-0"
            >
              <span>Test App</span>
              <ExternalLink size={14} />
            </button>
          </div>

          {/* Inside the APK: Contents breakdown */}
          <div className="border border-zinc-800 rounded-xl overflow-hidden bg-zinc-950/50">
            <div className="px-4 py-2.5 bg-zinc-900/80 border-b border-zinc-800 flex items-center justify-between">
              <span className="text-xs font-semibold text-zinc-300 font-sans flex items-center gap-2">
                <Package size={14} className="text-zinc-400" />
                Package Artifact Contents (Inside {fileName})
              </span>
              <span className="text-[11px] text-zinc-400 font-mono">ZIP archive structure</span>
            </div>
            <div className="p-4 space-y-2 font-mono text-xs text-zinc-300">
              <div className="flex items-center justify-between py-1 border-b border-zinc-850">
                <span className="text-zinc-200">classes.dex</span>
                <span className="text-zinc-400">14,290 DEX methods (Kotlin runtime + AndroidX)</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-zinc-850">
                <span className="text-emerald-300">assets/www/index.html</span>
                <span className="text-zinc-400">Scientific Calculator UI (loaded by WebView)</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-zinc-850">
                <span className="text-purple-300">AndroidManifest.xml</span>
                <span className="text-zinc-400">Binary XML (MainActivity registered)</span>
              </div>
              <div className="flex items-center justify-between py-1 border-b border-zinc-850">
                <span className="text-zinc-200">resources.arsc</span>
                <span className="text-zinc-400">Compiled string and drawable resources</span>
              </div>
              <div className="flex items-center justify-between py-1">
                <span className="text-amber-300">META-INF/CERT.RSA & CERT.SF</span>
                <span className="text-zinc-400">APK Signature Scheme v2/v3 signatures</span>
              </div>
            </div>
          </div>

          {/* ADB Terminal Install Command */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs text-zinc-400 font-sans font-medium flex items-center gap-1.5">
                <Terminal size={14} className="text-zinc-400" />
                <span>Deploy to connected Android device or emulator</span>
              </label>
              <button
                onClick={() => copyToClipboard(adbCommand, 'adb')}
                className="text-xs text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-mono"
              >
                {copiedCmd === 'adb' ? <Check size={13} /> : <Copy size={13} />}
                <span>{copiedCmd === 'adb' ? 'Copied command!' : 'Copy command'}</span>
              </button>
            </div>
            <div className="bg-zinc-950 rounded-xl p-3 border border-zinc-800 font-mono text-xs flex items-center justify-between">
              <span className="text-emerald-400 truncate">$ {adbCommand}</span>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-zinc-950 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
          <span>Gradle Task: <code className="text-zinc-300">:app:assembleDebug</code></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-medium transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
